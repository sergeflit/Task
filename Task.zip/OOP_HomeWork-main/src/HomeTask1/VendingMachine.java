package HomeTask1;

import java.util.List;

 public interface VendingMachine {
     void initProducts (List <Product> list);
    public Product getProduct(String name);




}

