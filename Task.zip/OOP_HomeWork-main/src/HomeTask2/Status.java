package HomeTask2;

public class Status {

}

