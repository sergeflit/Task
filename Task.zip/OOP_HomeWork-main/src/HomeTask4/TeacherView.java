package HomeTask4;

import java.util.List;

public class TeacherView {
    public void printTeachers(List<Teacher> teachers) {
        for (Teacher teacher : teachers) {
            System.out.println(teacher);
        }
    }
}

