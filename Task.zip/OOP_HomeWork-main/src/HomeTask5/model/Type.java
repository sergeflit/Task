package HomeTask5.model;

public enum Type {
    STUDENT,
    TEACHER
}
