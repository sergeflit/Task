package HomeTask5.view;

import HomeTask5.model.Student;

public class StudentView {
    public void printOnConsole(Student student){
        System.out.println(student.toString());
    }
}
