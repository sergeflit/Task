package HomeTask7.view;

public class CalculatorView {
    public void printResult(double result) {
        System.out.println("Результат: " + result);
    }
}


